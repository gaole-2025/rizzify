-- Add beautified to Section enum
ALTER TYPE "public"."Section" ADD VALUE 'beautified' AFTER 'uploaded';
